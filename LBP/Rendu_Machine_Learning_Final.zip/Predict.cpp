
#include <iostream>
#include <fstream>
#include <cmath>

struct park {

	int free;
	int lbp[256];
};

int main()
{
	std::ifstream training("C:/Users/Mad Scientifique/Documents/m2_numerisation/results/training.txt");
	std::ifstream test("C:/Users/Mad Scientifique/Documents/m2_numerisation/results/test.txt");
	
	park trainParks[200];
	park testParks[200];

	for (int line = 0; line < 200; line++) {

		for (int index = 0; index < 256; index++) {

			training >> trainParks[line].lbp[index];
			test >> testParks[line].lbp[index];
		}

		training >> trainParks[line].free;
		test >> testParks[line].free;
	}

	int nbCorrect = 0;

	for (int te = 0; te < 200; te++) {

		int distMin = INT_MAX;
		int minIndex = 0;

		for (int tr = 0; tr < 200; tr++) {

			int dist = 0;

			for (int index = 0; index < 256; index++) {

				dist += abs(trainParks[tr].lbp[index] - testParks[te].lbp[index]);
			}

			if (dist < distMin) {
				distMin = dist;
				minIndex = tr;
			}
		}

		if (testParks[te].free == trainParks[minIndex].free) { nbCorrect++; }
	}

	double predict = (nbCorrect * 1.0) / 200.0;

	std::cout << "les prédictions ont été correctes à " << predict*100 << "%!" << std::endl;

}

